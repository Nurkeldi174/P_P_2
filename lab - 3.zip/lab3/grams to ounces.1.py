def grams_ounces(grams):
    ounces = (grams * 28.3495231)
    return ounces

grams_input = float(input("grams:"))
ounces_output = grams_ounces(grams_input)
print(f"{ounces_output:.5f}")