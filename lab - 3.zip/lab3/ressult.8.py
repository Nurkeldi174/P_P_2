def spy_game(nums):
    result = []
    for x in nums:
        if x == 0 or x == 7:
            result.append(x)
    if result[0] == 0 and result[1] == 0 and result[2] == 7:
        return True
    else:
        return False
    
print(spy_game([1, 4, 0, 5, 0, 7, 4]))