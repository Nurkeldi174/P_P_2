def reverse_text(input_string):
    text = input_string.split()

    reversed_text = text[::-1]

    return ' '.join(reversed_text)

input_string = "We are ready"
output_string = reverse_text(input_string)
print(output_string)