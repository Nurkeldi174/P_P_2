def histogram(hh):
    for x in hh:
        print('*' * x)

#EXAMPLE
histogram([5, 8, 2])