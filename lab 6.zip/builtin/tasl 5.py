def Truevalue(tup):
    if all(tup):
        return True
    else:
        return False

intr = input("Tuple:")
tup = tuple(bool(int(x)) for x in intr.split())

res = Truevalue(tup)

print(res)
