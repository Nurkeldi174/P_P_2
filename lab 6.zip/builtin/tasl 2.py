import math

x = str(input("String"))

def count_case_letters(x):
    upper_count = x.count(''.join(filter(str.isupper, x)))
    lower_count = x.count(''.join(filter(str.islower, x)))
    return upper_count, lower_count


upper, lower = count_case_letters(x)
print("Upper case letters:", upper)
print("Lower case letters:", lower)