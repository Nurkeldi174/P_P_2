def fahrenheit_to_celsius(fahrenheit):
    """
    Convert Fahrenheit to Celsius.
    :param fahrenheit: Temperature in Fahrenheit
    :return: Equivalent temperature in Celsius
    """
    celsius = (fahrenheit - 32) * 5 / 9
    return celsius

# Example usage
fahrenheit_input = float(input("Enter temperature in Fahrenheit: "))
celsius_output = fahrenheit_to_celsius(fahrenheit_input)
print(f"{fahrenheit_input} Fahrenheit is equal to {celsius_output:.2f} Celsius.")
