from itertools import permutations
permut = permutations([4, 6, 8, 7])

for i in list(permut):  
    print (i)