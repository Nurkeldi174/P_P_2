numbers = [1, 2, 3, 4, 5, 7, 10, 11]
def filter_num(num):
    if(num % 2) != 0:

        return True
    else:
        return False
out_filter = filter(filter_num, numbers)
print(list(out_filter))