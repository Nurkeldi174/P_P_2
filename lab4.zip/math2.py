import math

h = int(input("Height: "))
a = int(input("1st base: "))
b = int(input("2nd base: "))

print(((a + b) / 2) * h)