def volume_sphere(nums):
    #V = 4(pr^3)/3

    p = 3.14
    volume = (4 * p * nums ** 3)/3
    return volume

radius_input = int(input("nums:"))
volume_output = volume_sphere(radius_input)
print(volume_output)
