b = int(input("base: "))
h = int(input("height: "))

print(h * b)