def unique(nums):
    uniq = []
    for x in nums:
        if nums.count(x) == 1:
            uniq.append(x)
    return uniq

mylist = [1, 1, 2, 3, 5, 5, 6, 7]        
print(unique(mylist))
