def head_legs(Nheads, Nlegs):
    #heads >> x + y = 35    
    #legs >> 2x + 4y = 94
    for x in range(Nheads):
        y = Nheads - x
        if 2 * x + 4 * y == Nlegs:
            return x, y
        
Nheads = 35
Nlegs = 94
rabbits, chickens = head_legs(Nheads, Nlegs)
print(f"{chickens}, {rabbits}")