import math

x = int(input("List:"))

def multiply(x):
    return math.prod(x)

result = multiply(x)
print(result)