def the_same_numbers(input_list):
    for x in range(input_list):
        if input_list[x]==3:
            if input_list[x - 1] == 3 or input_list[x + 1] == 3:
                return True
    return False

    print(the_same_numbers([1, 3, 3, 1]))
        

