import re

x = input("Your Text:")

def capital_space(x):
    return re.sub(r'(?<!^)([A-Z])', r' \1', x)

print(capital_space(x))