import math
import time

def timemath(value, milsecond):

    seconds = milsecond/1000
    time.sleep(seconds)
    res = math.sqrt(value)
    print(f"{value} and {res}")

value = float(input("number:"))
milsecond = int(input("time:"))

timemath(value, milsecond)