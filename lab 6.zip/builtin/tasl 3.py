x = str(input("txt"))

def palindrome(x):
    return x == x[::-1]

print(palindrome(x))