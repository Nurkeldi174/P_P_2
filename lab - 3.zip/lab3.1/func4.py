def average_imdb_score(movies):
    total_score = sum(movie['imdb_score'] for movie in movies)
    return total_score / len(movies)


movies = [
    {"title": "Inception", "imdb_score": 8.8},
    {"title": "The Dark Knight", "imdb_score": 9.0},
    {"title": "Interstellar", "imdb_score": 8.6},
    {"title": "Fight Club", "imdb_score": 8.8},
    {"title": "Pulp Fiction", "imdb_score": 8.9},
    {"title": "The Matrix", "imdb_score": 8.7}
]

avg_score = average_imdb_score(movies)
print(f"Average IMDb Score: {avg_score:.2f}")
