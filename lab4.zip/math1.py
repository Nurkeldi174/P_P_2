import math

n = int(input())

print(math.radians(n))