import datetime

current_time = datetime.datetime.now()

print(current_time.replace(microsecond=0))

#youtube.com/watch?v=qS0HlqjQHnk